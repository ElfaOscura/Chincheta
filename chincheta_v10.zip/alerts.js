'use strict';

/* ============================================================
   Alertas
   - Post-it naranja en el tablero con cuenta atrás y chincheta por urgencia.
   - Ventana de la campana para crear y administrar alertas.
   - Al llegar la hora: ventana en pantalla (Descartar / Prorrogar),
     notificación del sistema y un sonido suave.
   Este archivo se carga antes que app.js y usa sus funciones al ejecutarse.
   ============================================================ */

const ALERT_SOON_MS = 3 * 3600e3; // chincheta amarilla: faltan menos de 3 horas
const ALERT_NOW_MS = 15 * 60e3;   // chincheta roja: faltan 15 minutos o menos, o ya venció
const SNOOZE_MS = 10 * 60e3;      // "Prorrogar 10 minutos"
const WEEKDAYS = [[1, 'Lun'], [2, 'Mar'], [3, 'Mié'], [4, 'Jue'], [5, 'Vie'], [6, 'Sáb'], [0, 'Dom']]; // getDay()

/* ---------- Horarios ---------- */
/** Próxima vez que suena la alerta `a` ({ time, repeat }) después de `from` (milisegundos). */
function nextTrigger(a, from = Date.now()) {
  const [hh, mm] = a.time.split(':').map(Number);
  if (a.repeat.mode === 'once') {
    if (!a.repeat.date) return 0;
    const d = parseKey(a.repeat.date);
    return new Date(d.getFullYear(), d.getMonth(), d.getDate(), hh, mm, 0, 0).getTime();
  }
  const days = a.repeat.mode === 'daily' ? [0, 1, 2, 3, 4, 5, 6] : a.repeat.days;
  const base = new Date(from);
  for (let i = 0; i < 8; i++) {
    const c = new Date(base.getFullYear(), base.getMonth(), base.getDate() + i, hh, mm, 0, 0);
    if (c.getTime() > from && days.includes(c.getDay())) return c.getTime();
  }
  return 0;
}

/** Normaliza los campos propios de una alerta guardada (se usa al cargar y al importar). */
function sanitizeAlertFields(it) {
  const r = it.repeat && typeof it.repeat === 'object' ? it.repeat : {};
  const days = Array.isArray(r.days)
    ? [...new Set(r.days.map(Number).filter((d) => Number.isInteger(d) && d >= 0 && d <= 6))].sort()
    : [];
  let mode = ['once', 'daily', 'days'].includes(r.mode) ? r.mode : 'daily';
  if (mode === 'days' && !days.length) mode = 'daily';
  const date = typeof r.date === 'string' && isValidDate(r.date) ? r.date : '';
  if (mode === 'once' && !date) mode = 'daily';
  const out = {
    body: str(it.body, 2000),
    time: typeof it.time === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(it.time) ? it.time : '08:00',
    repeat: { mode, days, date },
    enabled: it.enabled !== false,
    done: !!it.done,
    fired: !!it.fired,
    snoozed: !!it.snoozed,
    next: num(it.next, 0),
  };
  if (out.enabled && !out.done && !out.fired && !out.next) out.next = nextTrigger(out);
  return out;
}

/** (Re)programa una alerta desde cero: la próxima vez que le toca sonar. */
function scheduleAlert(it) {
  it.fired = false;
  it.snoozed = false;
  it.done = false;
  it.next = it.enabled ? nextTrigger(it) : 0;
}

/* ---------- Textos ---------- */
function fmtClock(ms) {
  return new Date(ms).toLocaleTimeString('es-VE', { hour: 'numeric', minute: '2-digit' });
}
function fmtTime(hhmm) {
  const [hh, mm] = hhmm.split(':').map(Number);
  return fmtClock(new Date(2000, 0, 1, hh, mm).getTime());
}
const shortDate = (key) => {
  const d = parseKey(key);
  return `${DIAS[d.getDay()].slice(0, 3)} ${d.getDate()} ${MESES_CORTOS[d.getMonth()]}`;
};
function repeatLabel(r) {
  if (r.mode === 'once') return r.date ? `Una vez · ${shortDate(r.date)}` : 'Una vez';
  if (r.mode === 'daily') return 'Todos los días';
  const set = new Set(r.days);
  if (set.size === 7) return 'Todos los días';
  if (set.size === 5 && [1, 2, 3, 4, 5].every((d) => set.has(d))) return 'Lunes a viernes';
  return WEEKDAYS.filter(([d]) => set.has(d)).map(([, n]) => n).join(', ');
}
const scheduleLabel = (it) => `${fmtTime(it.time)} · ${repeatLabel(it.repeat)}`;
const alertMeta = (it) => (it.snoozed ? `Prorrogada · ${fmtClock(it.next)}` : scheduleLabel(it));

function fmtLeft(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(s / 86400), hh = Math.floor((s % 86400) / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60;
  if (d) return `${d} d ${hh} h ${mm} min`;
  if (hh) return `${hh} h ${mm} min`;
  return `${mm} min ${pad(ss)} s`;
}
function fmtAgo(ms) {
  const m = Math.floor(ms / 60000);
  if (m < 1) return 'ahora mismo';
  if (m < 60) return `hace ${m} min`;
  const hh = Math.floor(m / 60);
  if (hh < 24) return `hace ${hh} h ${m % 60} min`;
  return `hace ${Math.floor(hh / 24)} d`;
}
function countdownLabel(it, now = Date.now()) {
  if (it.done) return 'Cumplida';
  if (!it.enabled) return 'En pausa';
  if (it.fired || it.next <= now) return `Vencida ${fmtAgo(now - it.next)}`;
  return `Faltan ${fmtLeft(it.next - now)}`;
}

/** 'ok' (verde), 'soon' (amarillo), 'now' (rojo) u 'off' (en pausa o cumplida). */
function urgencyOf(it, now = Date.now()) {
  if (!it.enabled || it.done) return 'off';
  if (it.fired) return 'now';
  const left = it.next - now;
  return left <= ALERT_NOW_MS ? 'now' : left <= ALERT_SOON_MS ? 'soon' : 'ok';
}

/* ---------- Post-it del tablero ---------- */
function alertFace(it) {
  return [
    h('div', { class: 'alert-top' },
      h('span', { class: 'alert-bell ico', 'aria-hidden': 'true', text: '🔔' }),
      h('span', { class: 'countdown', text: countdownLabel(it) })),
    h('span', { class: 'item-title', text: it.title || 'Alerta' }),
    h('span', { class: 'alert-meta', text: alertMeta(it) }),
  ];
}

function setUrgency(node, u) {
  for (const c of ['ok', 'soon', 'now', 'off']) node.classList.toggle(`urg-${c}`, c === u);
}

/** Se ejecuta cada segundo: refresca cuentas atrás, colores de chincheta y campana. */
function updateAlertNodes() {
  const now = Date.now();
  for (const node of document.querySelectorAll('#items .item.type-alert')) {
    const it = byId(node.dataset.id);
    if (!it) continue;
    const c = node.querySelector('.countdown');
    const txt = countdownLabel(it, now);
    if (c && c.textContent !== txt) c.textContent = txt;
    const m = node.querySelector('.alert-meta');
    const meta = alertMeta(it);
    if (m && m.textContent !== meta) m.textContent = meta;
    setUrgency(node, urgencyOf(it, now));
  }
  updateBell(now);
  if ($('#alerts-dialog').open) updateAlertRows(now);
}

/* ---------- Campana de la barra superior ---------- */
function alertsBellSlot() {
  return h('li', { class: 'up-slot bell-slot' }, h('button', {
    type: 'button', class: 'up-card bell', id: 'alerts-btn', 'aria-label': 'Alertas',
    onclick: () => openAlerts(),
  },
  lucide('bell', 'bell-ico'),
  h('span', { text: 'Alertas' }),
  h('span', { class: 'bell-badge', hidden: true })));
}
function updateBell(now = Date.now()) {
  const btn = document.getElementById('alerts-btn');
  if (!btn) return;
  const active = state.items.filter((i) => i.type === 'alert' && i.enabled && !i.done);
  const badge = btn.querySelector('.bell-badge');
  badge.textContent = String(active.length);
  badge.hidden = active.length === 0;
  btn.classList.toggle('urgent', active.some((i) => urgencyOf(i, now) === 'now'));
  btn.setAttribute('aria-label', `Alertas, ${active.length} ${active.length === 1 ? 'activa' : 'activas'}`);
}

/* ---------- Ventana "Alertas" ---------- */
let alertEditing = null;
const alertSorted = () => state.items.filter((i) => i.type === 'alert').sort((a, b) => {
  const live = (x) => (x.enabled && !x.done ? 0 : 1);
  return live(a) - live(b) || (a.next || Infinity) - (b.next || Infinity);
});

function openAlerts(editId = null) {
  const dlg = $('#alerts-dialog');
  renderAlertList();
  resetAlertForm();
  updatePrefs();
  if (editId) editAlert(editId);
  if (!dlg.open) dlg.showModal();
}

/** Al tocar una alerta del tablero: si ya venció se muestra su aviso; si no, se abre para editarla. */
function openAlertItem(id) {
  const it = byId(id);
  if (!it) return;
  if (it.enabled && !it.done && (it.fired || it.next <= Date.now())) {
    if (!it.fired) { it.fired = true; save(); }
    fire.queue = fire.queue.filter((x) => x !== id);
    fire.queue.unshift(id);
    showNextFire();
  } else {
    openAlerts(id);
  }
}

function renderAlertList() {
  const list = $('#alerts-list');
  const items = alertSorted();
  if (!items.length) {
    list.replaceChildren(h('li', { class: 'list-empty', text: 'Aún no hay alertas. Crea la primera con el formulario.' }));
    return;
  }
  list.replaceChildren(...items.map((it) => {
    const live = it.enabled && !it.done;
    return h('li', { class: 'alert-row', dataset: { id: it.id } },
      h('span', { class: `al-dot urg-${urgencyOf(it)}`, 'aria-hidden': 'true' }),
      h('div', { class: 'al-main' },
        h('strong', { text: it.title || 'Alerta' }),
        h('span', { class: 'al-sched', text: alertMeta(it) }),
        h('span', { class: 'al-status', text: countdownLabel(it) }),
        it.body ? h('span', { class: 'al-body', text: it.body }) : null),
      h('div', { class: 'ev-btns' },
        actBtn(live ? 'pause' : 'play', `${live ? 'Pausar' : 'Activar'} ${it.title}`, () => toggleAlert(it.id)),
        actBtn('edit', `Editar ${it.title}`, () => editAlert(it.id)),
        actBtn('delete', `Eliminar ${it.title}`, () => removeAlert(it.id))));
  }));
}
function updateAlertRows(now = Date.now()) {
  for (const row of document.querySelectorAll('#alerts-list .alert-row')) {
    const it = byId(row.dataset.id);
    if (!it) continue;
    const s = row.querySelector('.al-status');
    const txt = countdownLabel(it, now);
    if (s.textContent !== txt) s.textContent = txt;
    row.querySelector('.al-dot').className = `al-dot urg-${urgencyOf(it, now)}`;
  }
}

function toggleAlert(id) {
  const it = byId(id);
  if (!it) return;
  if (it.enabled && !it.done) {
    it.enabled = false; it.fired = false; it.snoozed = false; it.next = 0;
    fire.queue = fire.queue.filter((x) => x !== id);
  } else {
    it.enabled = true;
    scheduleAlert(it);
    if (it.repeat.mode === 'once' && it.next <= Date.now()) {
      it.enabled = false; it.done = true; it.next = 0;
      toast('Esa alerta era de una sola vez y su hora ya pasó. Edítala para elegir otra fecha.');
    }
  }
  save();
  refreshItemNode(id);
  renderAlertList();
  updateBell();
}

async function removeAlert(id) {
  const it = byId(id);
  if (!it) return;
  if (!(await confirmDialog(`¿Eliminar la alerta «${it.title}»? También se quita su nota del tablero.`))) return;
  fire.queue = fire.queue.filter((x) => x !== id);
  if (alertEditing === id) resetAlertForm();
  deleteItem(id);
  renderAlertList();
  updateBell();
}

/* --- Formulario --- */
const alertMode = () => document.querySelector('input[name="al-mode"]:checked')?.value || 'once';
function syncRepeatUI() {
  const mode = alertMode();
  $('#al-date-wrap').hidden = mode !== 'once';
  $('#al-days-wrap').hidden = mode !== 'days';
}
function defaultWhen() {
  const d = new Date(Date.now() + 30 * 60e3);
  d.setMinutes(Math.ceil(d.getMinutes() / 5) * 5, 0, 0);
  return { date: dateKey(d), time: `${pad(d.getHours())}:${pad(d.getMinutes())}` };
}
function setDayChecks(days) {
  document.querySelectorAll('input[name="al-day"]').forEach((c) => { c.checked = days.includes(Number(c.value)); });
}
function resetAlertForm() {
  alertEditing = null;
  const w = defaultWhen();
  $('#al-title').value = '';
  $('#al-text').value = '';
  $('#al-time').value = w.time;
  $('#al-date').value = w.date;
  document.querySelector('input[name="al-mode"][value="once"]').checked = true;
  setDayChecks([]);
  $('#al-error').hidden = true;
  $('#alert-form-title').textContent = 'Nueva alerta';
  $('#al-save').textContent = 'Crear alerta';
  $('#al-cancel').hidden = true;
  syncRepeatUI();
}
function editAlert(id) {
  const it = byId(id);
  if (!it) return;
  alertEditing = id;
  $('#al-title').value = it.title;
  $('#al-text').value = it.body;
  $('#al-time').value = it.time;
  $('#al-date').value = it.repeat.date || defaultWhen().date;
  document.querySelector(`input[name="al-mode"][value="${it.repeat.mode}"]`).checked = true;
  setDayChecks(it.repeat.days);
  $('#al-error').hidden = true;
  $('#alert-form-title').textContent = 'Editar alerta';
  $('#al-save').textContent = 'Guardar cambios';
  $('#al-cancel').hidden = false;
  syncRepeatUI();
  $('#al-title').focus();
}

function submitAlertForm(e) {
  e.preventDefault();
  const err = $('#al-error');
  const fail = (msg, el) => { err.textContent = msg; err.hidden = false; el?.focus(); };
  const title = $('#al-title').value.trim();
  const time = $('#al-time').value;
  const mode = alertMode();
  const date = $('#al-date').value;
  const days = [...document.querySelectorAll('input[name="al-day"]:checked')].map((c) => Number(c.value));
  if (!title) return fail('Escribe un título para la alerta.', $('#al-title'));
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return fail('Elige la hora de la alerta.', $('#al-time'));
  if (mode === 'once' && !isValidDate(date)) return fail('Elige una fecha válida.', $('#al-date'));
  if (mode === 'days' && !days.length) return fail('Marca al menos un día de la semana.', document.querySelector('input[name="al-day"]'));
  const sched = { time, repeat: { mode, days: mode === 'days' ? days : [], date: mode === 'once' ? date : '' } };
  if (mode === 'once' && nextTrigger(sched) <= Date.now()) return fail('Esa fecha y hora ya pasaron.', $('#al-time'));
  err.hidden = true;

  const body = $('#al-text').value.trim();
  const creating = !alertEditing;
  let id = alertEditing;
  if (id) {
    const it = byId(id);
    Object.assign(it, { title, body, ...sched, enabled: true });
    scheduleAlert(it);
    fire.queue = fire.queue.filter((x) => x !== id);
  } else {
    const it = newItemBase('alert', { title, body, ...sched, enabled: true, done: false, fired: false, snoozed: false, next: 0 });
    scheduleAlert(it);
    state.items.push(it);
    id = it.id;
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().then(updatePrefs).catch(() => {});
    }
  }
  save();
  renderBoard();
  renderAlertList();
  updateBell();
  resetAlertForm();
  toast(creating ? 'Alerta creada. Quedó pegada en el tablero.' : 'Alerta guardada.');
  $('#al-title').focus();
}

/* --- Notificaciones y sonido --- */
function updatePrefs() {
  const st = $('#notif-status');
  const btn = $('#notif-btn');
  if (!('Notification' in window)) {
    st.textContent = 'Este navegador no permite notificaciones del sistema. Verás el aviso en pantalla.';
    btn.hidden = true;
  } else if (Notification.permission === 'granted') {
    st.textContent = 'Notificaciones del sistema activadas. Funcionan mientras Chincheta esté abierta (en una pestaña o instalada).';
    btn.hidden = true;
  } else if (Notification.permission === 'denied') {
    st.textContent = 'Las notificaciones están bloqueadas. Permítelas desde el candado de la barra de direcciones.';
    btn.hidden = true;
  } else {
    st.textContent = 'Activa las notificaciones del sistema para enterarte aunque estés en otra ventana.';
    btn.hidden = false;
  }
  $('#sound-toggle').checked = !!state.settings.sound;
}

let audioCtx = null;
function unlockAudio() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
  } catch { /* sin audio */ }
}
/** Dos "din-don" suaves hechos con osciladores (no hace falta ningún archivo de sonido). */
function playChime(force = false) {
  if (!force && !state.settings.sound) return;
  unlockAudio();
  const ctx = audioCtx;
  if (!ctx || ctx.state !== 'running') return;
  const t0 = ctx.currentTime + 0.03;
  [[659.25, 0], [880, 0.24], [659.25, 1.0], [880, 1.24]].forEach(([freq, dt]) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, t0 + dt);
    gain.gain.exponentialRampToValueAtTime(0.08, t0 + dt + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dt + 0.8);
    osc.connect(gain).connect(ctx.destination);
    osc.start(t0 + dt);
    osc.stop(t0 + dt + 0.85);
  });
}

async function notifyAlert(it) {
  playChime();
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const title = `🔔 ${it.title || 'Alerta'}`;
  const opts = {
    body: it.body || `Son las ${fmtClock(it.next)}`,
    tag: `chincheta-${it.id}`, renotify: true, requireInteraction: true,
    icon: 'icons/icon-192.png', badge: 'icons/icon-192.png',
    data: { id: it.id },
  };
  try {
    const reg = await navigator.serviceWorker?.getRegistration?.();
    if (reg) {
      await reg.showNotification(title, {
        ...opts,
        actions: [{ action: 'snooze', title: 'Prorrogar 10 min' }, { action: 'dismiss', title: 'Descartar' }],
      });
      return;
    }
  } catch { /* se prueba con la notificación simple */ }
  try { new Notification(title, opts); } catch { /* no crítico */ }
}

/* ---------- Aviso cuando se cumple la hora ---------- */
const fire = { queue: [], shown: new Set(), current: null };

function enqueueFire(id) {
  if (!fire.queue.includes(id) && fire.current !== id) fire.queue.push(id);
}

function showNextFire() {
  const dlg = $('#alert-dialog');
  if (dlg.open) return;
  while (fire.queue.length) {
    const id = fire.queue.shift();
    const it = byId(id);
    if (!it || it.type !== 'alert' || !it.enabled || !it.fired) continue;
    fire.current = id;
    fire.shown.add(id);
    $('#fire-title').textContent = it.title || 'Alerta';
    const text = $('#fire-text');
    text.textContent = it.body;
    text.hidden = !it.body;
    const late = Date.now() - it.next;
    $('#fire-when').textContent = late > 90e3 ? `Era para las ${fmtClock(it.next)} · ${fmtAgo(late)}` : `Son las ${fmtClock(it.next)}`;
    const count = $('#fire-count');
    count.textContent = `Alerta 1 de ${fire.queue.length + 1}`;
    count.hidden = fire.queue.length === 0;
    document.title = `🔔 ${it.title || 'Alerta'} · ${APP_NAME}`;
    dlg.showModal();
    $('#fire-dismiss').focus();
    return;
  }
  fire.current = null;
  document.title = APP_NAME;
}

/** Descartar: la alerta se cierra; si se repite, queda programada para su siguiente vez. */
function dismissAlert(id) {
  const it = byId(id);
  if (!it) return;
  it.fired = false;
  it.snoozed = false;
  if (it.repeat.mode === 'once') { it.done = true; it.enabled = false; it.next = 0; }
  else it.next = nextTrigger(it, Date.now());
  save();
  refreshItemNode(id);
  updateBell();
  if ($('#alerts-dialog').open) renderAlertList();
}

/** Prorrogar: vuelve a sonar dentro de 10 minutos. */
function snoozeAlert(id) {
  const it = byId(id);
  if (!it) return;
  it.fired = false;
  it.snoozed = true;
  it.next = Date.now() + SNOOZE_MS;
  save();
  refreshItemNode(id);
  updateBell();
  if ($('#alerts-dialog').open) renderAlertList();
}

function alertsTick() {
  const now = Date.now();
  for (const it of state.items) {
    if (it.type !== 'alert' || !it.enabled || it.done) continue;
    if (!it.fired && it.next && it.next <= now) {
      it.fired = true;
      save();
      notifyAlert(it);
      enqueueFire(it.id);
    } else if (it.fired && !fire.shown.has(it.id)) {
      enqueueFire(it.id); // venció mientras Chincheta estaba cerrada
    }
  }
  if (fire.queue.length) showNextFire();
  updateAlertNodes();
}

/** Un reloj dentro de un Worker: el navegador lo frena menos que a la página cuando está en segundo plano. */
function startAlertClock(fn) {
  try {
    const blob = new Blob(['setInterval(function(){postMessage(0)},1000)'], { type: 'text/javascript' });
    const worker = new Worker(URL.createObjectURL(blob));
    worker.onmessage = fn;
  } catch {
    setInterval(fn, 1000);
  }
}

function setupAlerts() {
  const dlg = $('#alerts-dialog');
  $('#alerts-close').addEventListener('click', () => dlg.close());
  enableBackdropClose(dlg);
  $('#alert-new').addEventListener('click', () => { resetAlertForm(); $('#al-title').focus(); });
  document.querySelectorAll('input[name="al-mode"]').forEach((r) => r.addEventListener('change', syncRepeatUI));
  $('#alert-form').addEventListener('submit', submitAlertForm);
  $('#al-cancel').addEventListener('click', resetAlertForm);

  $('#notif-btn').addEventListener('click', () => {
    Notification.requestPermission().then(updatePrefs).catch(() => {});
  });
  $('#sound-toggle').addEventListener('change', (e) => { state.settings.sound = e.target.checked; save(); });
  $('#sound-test').addEventListener('click', () => { unlockAudio(); setTimeout(() => playChime(true), 80); });

  const fireDlg = $('#alert-dialog');
  $('#fire-dismiss').addEventListener('click', () => { const id = fire.current; fireDlg.close(); dismissAlert(id); });
  $('#fire-snooze').addEventListener('click', () => { const id = fire.current; fireDlg.close(); snoozeAlert(id); });
  fireDlg.addEventListener('close', () => { fire.current = null; setTimeout(showNextFire, 200); });

  /* Los navegadores solo dejan sonar el audio después de un gesto del usuario */
  ['pointerdown', 'keydown'].forEach((ev) => document.addEventListener(ev, unlockAudio, { passive: true }));

  /* Botones de la notificación del sistema (Prorrogar / Descartar) */
  navigator.serviceWorker?.addEventListener('message', (e) => {
    const { type, action, id } = e.data || {};
    if (type !== 'alert-action' || !byId(id)) return;
    if (action === 'snooze') snoozeAlert(id);
    else if (action === 'dismiss') dismissAlert(id);
    else openAlertItem(id);
  });

  document.addEventListener('visibilitychange', () => { if (!document.hidden) alertsTick(); });
  startAlertClock(alertsTick);
  alertsTick();
}
